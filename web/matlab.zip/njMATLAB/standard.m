clc;
clear;
close all;

%% Baseline action potential of a healthy neuron

tspan = [0 40];
dt = 0.01;
t = tspan(1):dt:tspan(2);
N = length(t);

V0 = -70;
m0 = 0.05;
h0 = 0.60;
n0 = 0.32;
y0 = [V0 m0 h0 n0];

%% ODE45 SOLUTION
[t45,y45] = ode45(@HHmodel,t,y0);
V = y45(:,1);
m = y45(:,2);
h = y45(:,3);
n = y45(:,4);

% conductances from the gates
gNa = 120;
gK = 36;
gNa_t = gNa*(m.^3).*h;
gK_t = gK*(n.^4);

%% FIGURE - voltage, gates and conductances
figure('Position',[100 100 1280 720]);

% Plotting membrane voltage
subplot(3,1,1)
plot(t,V,'k','LineWidth',1.8)
hold on
yline(-55,'r--','Threshold')
yline(V0,'b--','Resting')
hold off
xlim(tspan)
ylim([-85 60])
grid on
title('Membrane Voltage')
ylabel('Voltage (mV)')

% Plotting gate probabilities
subplot(3,1,2)
hold on
plot(t,m,'LineWidth',1.5)
plot(t,h,'LineWidth',1.5)
plot(t,n,'LineWidth',1.5)
hold off
xlim(tspan)
ylim([0 1])
grid on
title('Gate Probabilities')
ylabel('Probability')
legend('m','h','n','Location','eastoutside')

% Plotting ionic conductances
subplot(3,1,3)
hold on
plot(t,gNa_t,'LineWidth',1.5)
plot(t,gK_t,'LineWidth',1.5)
hold off
xlim(tspan)
grid on
title('Ionic Conductances')
xlabel('Time (ms)')
ylabel('mS/cm^2')
legend('g_{Na}','g_K','Location','eastoutside')

sgtitle('Hodgkin-Huxley Baseline Response')
