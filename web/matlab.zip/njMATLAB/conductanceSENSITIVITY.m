clc;
clear;
close all;

%% Sweeps of the channel densities and the applied current

tspan = [0 40];
dt = 0.01;
t = tspan(1):dt:tspan(2);
N = length(t);

V0 = -70;
m0 = 0.05;
h0 = 0.60;
n0 = 0.32;
y0 = [V0 m0 h0 n0];

% Parameters
Cm = 1;
gL = 0.3;
ENa = 55;
EK = -77;
EL = -54.387;

%baseline values
gNa_base = 120;
gK_base = 36;
I_base = 10;

% Three cases per sweep
gNa_cases = [30 120 200];
gK_cases = [10 36 70];
I_cases = [0 10 25];

V_gNa = zeros(N,3);
V_gK = zeros(N,3);
V_I = zeros(N,3);

%% SWEEP LOOP
for s = 1:3
    for c = 1:3
        gNa = gNa_base;
        gK = gK_base;
        I = I_base;

        if s == 1
            gNa = gNa_cases(c);
        elseif s == 2
            gK = gK_cases(c);
        else
            I = I_cases(c);
        end

        y = y0;
        Vout = zeros(N,1);
        Vout(1) = V0;

        % Solving RK4 step
        for i = 1:N-1
            k1 = HHrhs(y,gNa,gK,gL,ENa,EK,EL,Cm,I);
            k2 = HHrhs(y+dt*k1/2,gNa,gK,gL,ENa,EK,EL,Cm,I);
            k3 = HHrhs(y+dt*k2/2,gNa,gK,gL,ENa,EK,EL,Cm,I);
            k4 = HHrhs(y+dt*k3,gNa,gK,gL,ENa,EK,EL,Cm,I);
            y = y + (dt/6)*(k1+2*k2+2*k3+k4);
            Vout(i+1) = y(1);
        end

        if s == 1
            V_gNa(:,c) = Vout;
        elseif s == 2
            V_gK(:,c) = Vout;
        else
            V_I(:,c) = Vout;
        end
    end
end

%% FIGURE - the three sweeps
figure('Position',[100 100 1280 720]);

% Plotting sodium conductance sweep
subplot(3,1,1)
hold on
plot(t,V_gNa(:,1),'r','LineWidth',1.5)
plot(t,V_gNa(:,2),'b','LineWidth',1.5)
plot(t,V_gNa(:,3),'g','LineWidth',1.5)
yline(-55,'k--')
hold off
xlim(tspan); ylim([-85 60]); grid on
title('Varying g_{Na} - Spike Height and Conduction Block')
ylabel('Voltage (mV)')
legend('g_{Na} = 30','g_{Na} = 120','g_{Na} = 200','Location','eastoutside')

% Plotting potassium conductance sweep
subplot(3,1,2)
hold on
plot(t,V_gK(:,1),'r','LineWidth',1.5)
plot(t,V_gK(:,2),'b','LineWidth',1.5)
plot(t,V_gK(:,3),'g','LineWidth',1.5)
yline(-55,'k--')
hold off
xlim(tspan); ylim([-85 60]); grid on
title('Varying g_K - Spike Frequency Control')
ylabel('Voltage (mV)')
legend('g_K = 10','g_K = 36','g_K = 70','Location','eastoutside')

% Plotting applied current sweep
subplot(3,1,3)
hold on
plot(t,V_I(:,1),'r','LineWidth',1.5)
plot(t,V_I(:,2),'b','LineWidth',1.5)
plot(t,V_I(:,3),'g','LineWidth',1.5)
yline(-55,'k--')
hold off
xlim(tspan); ylim([-85 60]); grid on
title('Varying I - Quiescence to Burst Firing')
xlabel('Time (ms)')
ylabel('Voltage (mV)')
legend('I = 0','I = 10','I = 25','Location','eastoutside')

sgtitle('Channel Density and Input Current Sensitivity')

%% HH right hand side
function dydt = HHrhs(y,gNa,gK,gL,ENa,EK,EL,Cm,I)
V = y(1);
m = y(2);
h = y(3);
n = y(4);

if abs(V+40) < 1e-7
    am = 1;
else
    am = 0.1*(V+40)/(1-exp(-(V+40)/10));
end

% Computing gate rates
bm = 4*exp(-(V+65)/18);
ah = 0.07*exp(-(V+65)/20);
bh = 1/(1+exp(-(V+35)/10));

if abs(V+55) < 1e-7
    an = 0.1;
else
    an = 0.01*(V+55)/(1-exp(-(V+55)/10));
end

bn = 0.125*exp(-(V+65)/80);

% HH Differential equations
dV = (I - gNa*m^3*h*(V-ENa) - gK*n^4*(V-EK) - gL*(V-EL))/Cm;
dm = am*(1-m) - bm*m;
dh = ah*(1-h) - bh*h;
dn = an*(1-n) - bn*n;

dydt = [dV dm dh dn];
end
