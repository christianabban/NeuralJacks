clc;
clear;
close all;

%% Equilibrium Function of the gating variables

Vrest = 0;
voltage = -100:0.01:100;
N = length(voltage);

xm = zeros(1,N);
xn = zeros(1,N);
xh = zeros(1,N);
taum = zeros(1,N);
taun = zeros(1,N);
tauh = zeros(1,N);

%% equilibrium values over the voltage range
for i = 1:N
    [alphaN, betaN] = n_equations(voltage(i), Vrest);
    [alphaM, betaM] = m_equations(voltage(i), Vrest);
    [alphaH, betaH] = h_equations(voltage(i), Vrest);

    taum(i) = 1/(alphaM+betaM);
    taun(i) = 1/(alphaN+betaN);
    tauh(i) = 1/(alphaH+betaH);

    xm(i) = alphaM/(alphaM+betaM);
    xn(i) = alphaN/(alphaN+betaN);
    xh(i) = alphaH/(alphaH+betaH);
end

%% EQUILIBRIUM FUNCTION
figure('Name','Equilibrium Function','Position',[100 100 1280 720]);

plot(voltage, xm, 'b', voltage, xn, 'g', voltage, xh, 'r', 'LineWidth', 2);
legend('m','n','h');
title('Equilibrium Function');
xlabel('mV');
ylabel('x(u)');
xlim([-100 100])
ylim([0 1])
grid on

%calculate alpha m and beta m based on Table 2
function [alpha_m, beta_m] = m_equations(V, Vrest)
if abs(2.5-0.1*(V-Vrest)) < 1e-9
    alpha_m = 1;
else
    alpha_m = (2.5-0.1*(V-Vrest))/(exp(2.5-0.1*(V-Vrest))-1);
end
beta_m = 4*exp((Vrest-V)/18);
end

%calculate alpha n and beta n based on Table 2
function [alpha_n, beta_n] = n_equations(V, Vrest)
if abs(1-0.1*(V-Vrest)) < 1e-9
    alpha_n = 0.1;
else
    alpha_n = (0.1-0.01*(V-Vrest))/(exp(1-0.1*(V-Vrest))-1);
end
beta_n = 0.125*exp((Vrest-V)/80);
end

%calculate alpha h and beta h based on Table 2
function [alpha_h, beta_h] = h_equations(V, Vrest)
alpha_h = 0.07*exp((Vrest-V)/20);
beta_h = 1/(1+exp(3-0.1*(V-Vrest)));
end
