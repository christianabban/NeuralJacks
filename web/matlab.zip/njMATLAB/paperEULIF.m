clc;
clear;
close all;

%% Integrated function against Euler's method for 5 ms with time step 0.1

R = 1;
tau = 1;
I = 3;

dt = 0.1;
totalTime = 5;
t = 0:dt:totalTime;
N = length(t);

%% Euler stepping
v = zeros(1,N);

for i = 1:N-1
    F = (R*I - v(i))/tau;
    v(i+1) = v(i) + F*dt;
end

%integrated solution on a fine grid
tfine = 0:0.001:totalTime;
vexact = R*I*(1-exp(-tfine/tau));

%same solution at the Euler points
vpoints = R*I*(1-exp(-t/tau));
gap = max(abs(v - vpoints));

fprintf('largest gap: %.4f mV\n',gap);

%% EULER AGAINST THE INTEGRATED FUNCTION
figure('Name','Euler','Position',[100 100 1280 720]);

hold on
%integrated function
plot(tfine, vexact, 'r', 'LineWidth', 2)
%Euler estimate
plot(t, v, 'go-', 'LineWidth', 1.5, 'MarkerSize', 6)
hold off
xlabel('Time (ms)')
ylabel('v (mV)')
title('Integrated Function and Euler''s Method')
legend('Integrated','Euler','Location','southeast')
xlim([0 totalTime])
grid on
