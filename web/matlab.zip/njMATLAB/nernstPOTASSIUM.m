clc;
clear;
close all;

%% Time and Initial Conditions
tspan = [0 50];
V0 = -70;
m0 = 0.05;
h0 = 0.60;
n0 = 0.32;
y0 = [V0; m0; h0; n0];

%% Reversal Potentials
E_K_healthy = -77;    % Healthy clearance ([K+]o = 3.5 mM)
E_K_failure = -65.6;  % Astrocytic clearance failure ([K+]o = 12.0 mM)

%% ODE Simulations
[t_healthy, y_healthy] = ode45(@(t,y) HH_model(t, y, E_K_healthy), tspan, y0);
[t_failure, y_failure] = ode45(@(t,y) HH_model(t, y, E_K_failure), tspan, y0);

%% FIGURE - Overlaid Voltage Comparison
figure('Position', [100 100 1000 600]);
plot(t_healthy, y_healthy(:,1), 'b', 'LineWidth', 1.8)
hold on
plot(t_failure, y_failure(:,1), 'r--', 'LineWidth', 1.8)
yline(-55, 'k:', 'Threshold (-55 mV)', 'LineWidth', 1.2)
yline(V0, 'k--', 'Resting (-70 mV)', 'LineWidth', 1.2)
hold off

grid on
xlim(tspan)
ylim([-85 60])
title('Impact of Astrocytic K^+ Clearance Failure on Membrane Voltage')
xlabel('Time (ms)')
ylabel('Membrane Voltage (mV)')
legend('Healthy (E_K = -77 mV)', 'Astrocytic Failure (E_K = -65.6 mV)', ...
       'Location', 'northeast')

%% Hodgkin-Huxley Differential Equations
function dydt = HH_model(~, y, E_K)
    V = y(1);
    m = y(2);
    h = y(3);
    n = y(4);

    % Conductances and Fixed Reversal Potentials
    g_Na = 120; g_K = 36; g_L = 0.3;
    E_Na = 50;  E_L = -54.4;

    % Baseline applied current
    I_app = 10;

    % Rate equations
    if abs(V+40) < 1e-7
        am = 1;
    else
        am = 0.1*(V+40)/(1-exp(-(V+40)/10));
    end
    bm = 4*exp(-(V+65)/18);
    ah = 0.07*exp(-(V+65)/20);
    bh = 1/(1+exp(-(V+35)/10));
    
    if abs(V+55) < 1e-7
        an = 0.1;
    else
        an = 0.01*(V+55)/(1-exp(-(V+55)/10));
    end
    bn = 0.125*exp(-(V+65)/80);

    % Derivatives
    dVdt = I_app - g_Na*(m^3)*h*(V - E_Na) - g_K*(n^4)*(V - E_K) - g_L*(V - E_L);
    dmdt = am*(1-m) - bm*m;
    dhdt = ah*(1-h) - bh*h;
    dndt = an*(1-n) - bn*n;

    dydt = [dVdt; dmdt; dhdt; dndt];
end