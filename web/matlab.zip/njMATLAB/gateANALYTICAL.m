clc;
clear;
close all;

%% Analytical gate solution under a voltage clamp
% holding V fixed makes alpha and beta constants, so the gateequation drops
% to x(t) = xinf + (x0 - xinf)*exp(-t/tau) which can be solved for exact values

Vclamp = -65;
tspan = [0 30];
dt = 0.01;
t = tspan(1):dt:tspan(2);

%% rates at the clamp voltage
if abs(Vclamp+40) < 1e-7
    am = 1;
else
    am = 0.1*(Vclamp+40)/(1-exp(-(Vclamp+40)/10));
end

% Computing gate rates
bm = 4*exp(-(Vclamp+65)/18);
ah = 0.07*exp(-(Vclamp+65)/20);
bh = 1/(1+exp(-(Vclamp+35)/10));

if abs(Vclamp+55) < 1e-7
    an = 0.1;
else
    an = 0.01*(Vclamp+55)/(1-exp(-(Vclamp+55)/10));
end

bn = 0.125*exp(-(Vclamp+65)/80);

%% steady states and time constants
minf = am/(am+bm);
hinf = ah/(ah+bh);
ninf = an/(an+bn);

tau_m = 1/(am+bm);
tau_h = 1/(ah+bh);
tau_n = 1/(an+bn);

fprintf('at V = %d mV\n',Vclamp);
fprintf('  m: minf = %.4f, tau = %.3f ms\n',minf,tau_m);
fprintf('  h: hinf = %.4f, tau = %.3f ms\n',hinf,tau_h);
fprintf('  n: ninf = %.4f, tau = %.3f ms\n',ninf,tau_n);

%% three starting points for the n gate
n_start = [0.05 0.32 0.80];
n1 = ninf + (n_start(1)-ninf)*exp(-t/tau_n);
n2 = ninf + (n_start(2)-ninf)*exp(-t/tau_n);
n3 = ninf + (n_start(3)-ninf)*exp(-t/tau_n);

% all three gates relaxing from zero
mt = minf + (0-minf)*exp(-t/tau_m);
ht = hinf + (0-hinf)*exp(-t/tau_h);
nt = ninf + (0-ninf)*exp(-t/tau_n);

%% FIGURE - gate relaxation
figure('Position',[100 100 1280 720]);

subplot(2,1,1)
hold on
% Plotting reduced start
plot(t,n1,'r','LineWidth',1.6)
% Plotting normal start
plot(t,n2,'b','LineWidth',1.6)
% Plotting excessive start
plot(t,n3,'g','LineWidth',1.6)
yline(ninf,'k--','n_{inf}')
hold off
xlim(tspan)
ylim([0 1])
grid on
title('Potassium Gate Relaxing to Steady State')
ylabel('n')
legend('n_0 = 0.05','n_0 = 0.32','n_0 = 0.80','Location','eastoutside')

% Plotting the three gates from zero
subplot(2,1,2)
hold on
plot(t,mt,'LineWidth',1.6)
plot(t,ht,'LineWidth',1.6)
plot(t,nt,'LineWidth',1.6)
hold off
xlim(tspan)
ylim([0 1])
grid on
title('All Three Gates Relaxing From Zero')
xlabel('Time (ms)')
ylabel('Probability')
legend('m','h','n','Location','eastoutside')

sgtitle('Closed Form Gate Solution at a Fixed Voltage')

%At V = -65 mV, inf represents the final percentage of open gates, meaning only 5% of Na+ activation gates (minf = 0.05), 60% of inactivation gates (hinf = 0.60), and 
% 32% of K+ gates (ninf = 0.32) stay open at equilibrium. Meanwhile, tau dictates how fast they reach those levels, where m's taum = 0.24 ms allows it to react 
% instantaneously compared to the  slower delays of n (taun = 5.46 ms) and h (tauh = 8.52 ms).
