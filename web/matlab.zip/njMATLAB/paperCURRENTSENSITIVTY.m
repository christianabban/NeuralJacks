clc;
clear;
close all;

%% Three examples of how an input current produces an action potential

Vrest = 0;
dt = 0.01;
totalTime = 150;
C = 1;

%constants; values based on Table 1
E_Na = 115 + Vrest;
E_K = -12 + Vrest;
E_Leak = 10.6 + Vrest;
g_Na = 120;
g_K = 36;
g_Leak = 0.3;

%Vector of time steps
t = 0:dt:totalTime;
N = length(t);

%input starts at 50 ms, the first 50 ms lets the ionic flows stabilize
tOn = 50;
I_cases = [2 4 7];

%the graphs ignore the first 45 ms
istart = 45/dt;

figure('Position',[100 100 1400 900]);

%% one row per input current
for c = 1:3
    I_current = zeros(1,N);
    I_current(tOn/dt:end) = I_cases(c);

    %initializing values
    V = zeros(1,N+1);
    m = zeros(1,N+1);
    n = zeros(1,N+1);
    h = zeros(1,N+1);
    conductance_K = zeros(1,N);
    conductance_Na = zeros(1,N);
    I_Na = zeros(1,N);
    I_K = zeros(1,N);
    I_Leak = zeros(1,N);

    V(1) = Vrest;

    %separate functions to get the alpha and beta values
    [alphaM, betaM] = m_equations(V(1), Vrest);
    [alphaN, betaN] = n_equations(V(1), Vrest);
    [alphaH, betaH] = h_equations(V(1), Vrest);

    %initializing gating variables to the asymptotic values
    m(1) = alphaM/(alphaM + betaM);
    n(1) = alphaN/(alphaN + betaN);
    h(1) = alphaH/(alphaH + betaH);

    for i = 1:N
        %calculate new alpha and beta based on last known membrane potential
        [alphaN, betaN] = n_equations(V(i), Vrest);
        [alphaM, betaM] = m_equations(V(i), Vrest);
        [alphaH, betaH] = h_equations(V(i), Vrest);

        %conductance variables
        conductance_K(i) = g_K*(n(i)^4);
        conductance_Na(i) = g_Na*(m(i)^3)*h(i);

        % ionic currents
        I_Na(i) = conductance_Na(i)*(V(i)-E_Na);
        I_K(i) = conductance_K(i)*(V(i)-E_K);
        I_Leak(i) = g_Leak*(V(i)-E_Leak);

        %Calculating the input
        Input = I_current(i) - (I_Na(i) + I_K(i) + I_Leak(i));

        %Calculating the new membrane potential
        V(i+1) = V(i) + Input*dt*(1/C);

        %getting new values for the gating variables
        m(i+1) = m(i) + (alphaM*(1-m(i)) - betaM*m(i))*dt;
        n(i+1) = n(i) + (alphaN*(1-n(i)) - betaN*n(i))*dt;
        h(i+1) = h(i) + (alphaH*(1-h(i)) - betaH*h(i))*dt;
    end

    %input on top and membrane potential underneath
    subplot(6,3,(c-1)*6+1)
    plot(t(istart:end), I_current(istart:end), 'r', 'LineWidth', 2)
    xlabel('Time (ms)')
    ylabel('\muA/cm^2')
    title('Input')
    xlim([45 totalTime])
    ylim([0 8])
    grid on

    subplot(6,3,(c-1)*6+4)
    plot(t(istart:end), V(istart:end-1), 'b', 'LineWidth', 2)
    xlabel('Time (ms)')
    ylabel('Voltage (mV)')
    title('Action Potential')
    xlim([45 totalTime])
    ylim([-20 120])
    grid on

    %gating parameters
    subplot(6,3,[(c-1)*6+2 (c-1)*6+5])
    plot(t(istart:end), m(istart:end-1), 'r', ...
         t(istart:end), n(istart:end-1), 'b', ...
         t(istart:end), h(istart:end-1), 'g', 'LineWidth', 2)
    legend('m','n','h')
    xlabel('Time (ms)')
    title('Gating Parameters')
    xlim([45 totalTime])
    ylim([0 1])
    grid on

    %conductance against the action potential
    subplot(6,3,[(c-1)*6+3 (c-1)*6+6])
    plot(t(istart:end), V(istart:end-1), 'r', ...
         t(istart:end), conductance_Na(istart:end), 'b', ...
         t(istart:end), conductance_K(istart:end), 'g', 'LineWidth', 2)
    legend('Action Potential','Na+ Conductance','K+ Conductance')
    xlabel('Time (ms)')
    ylabel('Voltage (mV)')
    title('Conduction of K+ and Na+')
    xlim([45 totalTime])
    ylim([-20 120])
    grid on
end

%calculate alpha m and beta m based on Table 2
function [alpha_m, beta_m] = m_equations(V, Vrest)
if abs(2.5-0.1*(V-Vrest)) < 1e-9
    alpha_m = 1;
else
    alpha_m = (2.5-0.1*(V-Vrest))/(exp(2.5-0.1*(V-Vrest))-1);
end
beta_m = 4*exp((Vrest-V)/18);
end

%calculate alpha n and beta n based on Table 2
function [alpha_n, beta_n] = n_equations(V, Vrest)
if abs(1-0.1*(V-Vrest)) < 1e-9
    alpha_n = 0.1;
else
    alpha_n = (0.1-0.01*(V-Vrest))/(exp(1-0.1*(V-Vrest))-1);
end
beta_n = 0.125*exp((Vrest-V)/80);
end

%calculate alpha h and beta h based on Table 2
function [alpha_h, beta_h] = h_equations(V, Vrest)
alpha_h = 0.07*exp((Vrest-V)/20);
beta_h = 1/(1+exp(3-0.1*(V-Vrest)));
end
