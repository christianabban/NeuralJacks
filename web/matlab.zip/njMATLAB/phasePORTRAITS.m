clc;
clear;
close all;

%% Hodgkin-Huxley Model: Phase Portraits (ODE45 Only)
tspan = [0 40];
V0 = -70;
m0 = 0.05;
h0 = 0.60;

% Parameters
Cm = 1;
gNa = 120;
gK = 36;
gL = 0.3;
ENa = 55;
EK = -77;
EL = -54.387;
I = 10;

params = [Cm, gNa, gK, gL, ENa, EK, EL, I];

% Three K+ activation cases (columns) using ode45
opts = odeset('RelTol',1e-6,'AbsTol',1e-8);
[tA, yA] = ode45(@(t,y) HH_rhs(t,y,params), tspan, [V0 m0 h0 0.05], opts);
[tB, yB] = ode45(@(t,y) HH_rhs(t,y,params), tspan, [V0 m0 h0 0.32], opts);
[tC, yC] = ode45(@(t,y) HH_rhs(t,y,params), tspan, [V0 m0 h0 0.80], opts);

%  phase portraits
figure('Position',[100 100 1280 720]);

% Plotting V-n phase portrait (n0 = 0.05)
subplot(3,3,1)
plot(yA(:,1), yA(:,4), 'r', 'LineWidth', 1.5)
title('n_0 = 0.05  V_m vs n')
xlabel('V_m (mV)')
ylabel('n')
xlim([-80 55])
ylim([0 1])
axis square
grid on

% Plotting V-n phase portrait (n0 = 0.32)
subplot(3,3,2)
plot(yB(:,1), yB(:,4), 'k', 'LineWidth', 1.5)
title('n_0 = 0.32  V_m vs n')
xlabel('V_m (mV)')
ylabel('n')
xlim([-80 55])
ylim([0 1])
axis square
grid on

% Plotting V-n phase portrait (n0 = 0.80)
subplot(3,3,3)
plot(yC(:,1), yC(:,4), 'g', 'LineWidth', 1.5)
title('n_0 = 0.80  V_m vs n')
xlabel('V_m (mV)')
ylabel('n')
xlim([-80 55])
ylim([0 1])
axis square
grid on

% Plotting V-m phase portrait (n0 = 0.05)
subplot(3,3,4)
plot(yA(:,1), yA(:,2), 'r', 'LineWidth', 1.5)
title('n_0 = 0.05  V_m vs m')
xlabel('V_m (mV)')
ylabel('m')
xlim([-80 55])
ylim([0 1])
axis square
grid on

% Plotting V-m phase portrait (n0 = 0.32)
subplot(3,3,5)
plot(yB(:,1), yB(:,2), 'k', 'LineWidth', 1.5)
title('n_0 = 0.32  V_m vs m')
xlabel('V_m (mV)')
ylabel('m')
xlim([-80 55])
ylim([0 1])
axis square
grid on

% Plotting V-m phase portrait (n0 = 0.80)
subplot(3,3,6)
plot(yC(:,1), yC(:,2), 'g', 'LineWidth', 1.5)
title('n_0 = 0.80  V_m vs m')
xlabel('V_m (mV)')
ylabel('m')
xlim([-80 55])
ylim([0 1])
axis square
grid on

% Plotting m-n phase portrait (n0 = 0.05)
subplot(3,3,7)
plot(yA(:,2), yA(:,4), 'r', 'LineWidth', 1.5)
title('n_0 = 0.05  m vs n')
xlabel('m')
ylabel('n')
xlim([0 1])
ylim([0 1])
axis square
grid on

% Plotting m-n phase portrait (n0 = 0.32)
subplot(3,3,8)
plot(yB(:,2), yB(:,4), 'k', 'LineWidth', 1.5)
title('n_0 = 0.32  m vs n')
xlabel('m')
ylabel('n')
xlim([0 1])
ylim([0 1])
axis square
grid on

% Plotting m-n phase portrait (n0 = 0.80)
subplot(3,3,9)
plot(yC(:,2), yC(:,4), 'g', 'LineWidth', 1.5)
title('n_0 = 0.80  m vs n')
xlabel('m')
ylabel('n')
xlim([0 1])
ylim([0 1])
axis square
grid on

sgtitle('Hodgkin-Huxley Phase Portraits (ODE45 Solution)')

%% Right hand side function for ODE45
function dydt = HH_rhs(~, y, params)
    Cm   = params(1);
    gNa  = params(2);
    gK   = params(3);
    gL   = params(4);
    ENa  = params(5);
    EK   = params(6);
    EL   = params(7);
    I    = params(8);

    V = y(1);
    m = y(2);
    h = y(3);
    n = y(4);

    if abs(V+40) < 1e-7
        am = 1;
    else
        am = 0.1*(V+40)/(1-exp(-(V+40)/10));
    end
    bm = 4*exp(-(V+65)/18);

    ah = 0.07*exp(-(V+65)/20);
    bh = 1/(1+exp(-(V+35)/10));

    if abs(V+55) < 1e-7
        an = 0.1;
    else
        an = 0.01*(V+55)/(1-exp(-(V+55)/10));
    end
    bn = 0.125*exp(-(V+65)/80);

    dV = (I - gNa*m^3*h*(V-ENa) - gK*n^4*(V-EK) - gL*(V-EL))/Cm;
    dm = am*(1-m) - bm*m;
    dh = ah*(1-h) - bh*h;
    dn = an*(1-n) - bn*n;

    dydt = [dV; dm; dh; dn];
end

% The top row's (Vm vs n) wide loop proves slow K+ gates lag behind voltage to drive repolarization, while the middle row's 
% (Vm vs m) tight diagonal shows fast Na+ gates open synchronously with voltage. The bottom row's (m vs n) L-shape proves
% a+ gates open completely before K+ gates even move. Across columns, loop sizes reveal gating physics: expanded loops 
% at n0 = 0.05 show how uninhibited Na+ influx increases overshoot, while squashed loops at n0 = 0.80 prove how 
%     pre-existing K+ outflow enforces the refractory state.