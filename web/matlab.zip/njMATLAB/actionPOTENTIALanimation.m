% 3D ACTION POTENTIAL PROPAGATION ANIMATION
% Hodgkin-Huxley Inspired Spatial Visualization
clear;
clc;
close all;
% Sspatial domain and grid setup
L = 50;                         % Membrane size (mm)
Nx = 80;                        % Number of x grid points
Ny = 80;                        % Number of y grid points
x = linspace(0,L,Nx);
y = linspace(0,L,Ny);
[X,Y] = meshgrid(x,y);

% EXCITATION CENTER & RADIAL DISTANCE
% stimulus origin at center (25 mm, 25 mm)
% radial distance R from center to every coordinate on the grid
x0 = L/2;
y0 = L/2;
R = sqrt((X-x0).^2 + (Y-y0).^2);

% TIME & PROPAGATION PARAMETERS
%  wave speed, spatial pulse width, and electrical voltage bounds
t = linspace(0,20,150);         % Time array (0 to 20 ms across 150 frames)
speed = 2;                      % Conduction velocity v (mm/ms)
width = 3;                      % Spatial wavefront width w (mm)
V_rest = -65;                   % Resting membrane potential (mV)
V_peak = 35;                    % Peak action potential overshoot (mV)

% video
videoFileName = 'Action Potential Animation.mp4';
fullSavePath = fullfile(pwd, videoFileName);
video = VideoWriter(fullSavePath, 'MPEG-4');
video.FrameRate = 20;
video.Quality = 100;
open(video);

% surface plot
% Builds 3D surface plot at resting potential V_rest (-65 mV)
fig = figure('Color','w','Position',[100 80 1000 750]);
V = V_rest * ones(size(X));
hSurf = surf(X, Y, V, V);
shading interp;
colormap(jet);
colorbar;
clim([V_rest V_peak]);
xlim([0 L]);
ylim([0 L]);
zlim([V_rest V_peak]);
xlabel('Distance (mm)');
ylabel('Distance (mm)');
zlabel('Membrane Potential (mV)');
title('Action Potential Propagation');
view(45,30);
grid on
box on;

% animation
% Computes expanding Gaussian wave envelope V(R,t) and writes frames to MP4
for k = 1:length(t)
    current_time = t(k);
    % Radius of expanding depolarizing wavefront (r = v * t)
    radius = speed * current_time;
    % Gaussian spatial profile generating voltage spike from resting to peak
    amplitude = (V_peak - V_rest) .* exp(-(R-radius).^2 / (2*width^2));
    % Total membrane potential superposition
    V = V_rest + amplitude;
    % Update 3D surface elevation (ZData) and color distribution (CData)
    set(hSurf, 'ZData', V, 'CData', V);
    title(sprintf('Action Potential Propagation   t = %.2f ms', current_time), ...
          'FontSize', 14, 'FontWeight', 'bold');
    drawnow;
    frame = getframe(fig);
    writeVideo(video, frame);
end
close(video);
