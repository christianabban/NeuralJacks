clc;
clear;
close all;

%% Solver accuracy against ODE45 setup
tspan = [0 50];
dt = 0.01;
t = tspan(1):dt:tspan(2);
N = length(t);
V0 = -70;
m0 = 0.05;
h0 = 0.60;
n0 = 0.32;
y0 = [V0 m0 h0 n0];

%% SOLVING
[y_FE,y_BE,y_ME,y_RK,t45,y45,exec_times] = HH_solvers(y0,t,dt,tspan);
V_FE = y_FE(:,1);
V_BE = y_BE(:,1);
V_ME = y_ME(:,1);
V_RK = y_RK(:,1);
V_45 = interp1(t45,y45(:,1),t,'pchip')';

% Absolute errors relative to ODE45
err_FE = abs(V_FE - V_45);
err_BE = abs(V_BE - V_45);
err_ME = abs(V_ME - V_45);
err_RK = abs(V_RK - V_45);
Vall_err = [err_FE, err_BE, err_ME, err_RK];
names = {'Forward Euler','Backward Euler','Modified Euler','RK4'};

%% ACCURACY TABLE COMPUTATION & CONSOLE PRINTING
Vall = [V_FE V_BE V_ME V_RK];
orders = [1 1 2 4];
meanRel = zeros(4,1);
maxAbs = zeros(4,1);

for c = 1:4
    d = abs(Vall(:,c) - V_45);
    meanRel(c) = mean(d./max(abs(V_45),eps));
    maxAbs(c) = max(d);
end

fprintf('\nsolver accuracy against ode45, dt = %g ms over %g ms\n\n',dt,tspan(2));
fprintf('%-16s %6s %14s %14s %14s\n','solver','order','mean rel','max abs (mV)','time (ms)');
for c = 1:4
    fprintf('%-16s %6d %14.4e %14.4e %14.4e\n', ...
        names{c},orders(c),meanRel(c),maxAbs(c),exec_times(c)*1000);
end

%% FIGURE 1 - 3D Line Absolute Voltage Error (All Solvers)
figure('Position',[100 100 1200 750]);
hold on
plot3(t,ones(size(t))*1,err_FE,'r','LineWidth',1.5)
plot3(t,ones(size(t))*2,err_BE,'b','LineWidth',1.5)
plot3(t,ones(size(t))*3,err_ME,'g','LineWidth',1.5)
plot3(t,ones(size(t))*4,err_RK,'m','LineWidth',1.5)
hold off
grid on
box on
view([-37.5 30])
title(['Solver Error Comparison at n_0 = ',num2str(n0)])
xlabel('Time (ms)')
ylabel('Solver')
zlabel('Absolute Error (mV)')
yticks(1:4)
yticklabels(names)
legend(names,'Location','northeast')
xlim(tspan)

%% FIGURE 2 - 2x2 3D Error Surfaces (One per Solver Showing Error Ridges)
dt_values = [0.005 0.010 0.015 0.020 0.025];
error_FE = zeros(length(dt_values),length(t));
error_BE = zeros(length(dt_values),length(t));
error_ME = zeros(length(dt_values),length(t));
error_RK = zeros(length(dt_values),length(t));

for k = 1:length(dt_values)
    dt_current = dt_values(k);
    t_current = tspan(1):dt_current:tspan(2);
    [y_FE_current,y_BE_current,y_ME_current,y_RK_current,t45_current,y45_current,~] = HH_solvers(y0,t_current,dt_current,tspan);
    V_45_current = interp1(t45_current,y45_current(:,1),t,'pchip')';
    V_FE_current = interp1(t_current,y_FE_current(:,1),t,'pchip')';
    V_BE_current = interp1(t_current,y_BE_current(:,1),t,'pchip')';
    V_ME_current = interp1(t_current,y_ME_current(:,1),t,'pchip')';
    V_RK_current = interp1(t_current,y_RK_current(:,1),t,'pchip')';
    error_FE(k,:) = abs(V_FE_current - V_45_current);
    error_BE(k,:) = abs(V_BE_current - V_45_current);
    error_ME(k,:) = abs(V_ME_current - V_45_current);
    error_RK(k,:) = abs(V_RK_current - V_45_current);
end

% Derivative of voltage to map phase space ridges during fast action potential dynamics
[T_grid,dt_grid] = meshgrid(t,dt_values);
figure('Position',[50 50 1400 850]);
for c = 1:4
    subplot(2,2,c)
    if c == 1
        Err_surface = error_FE;
    elseif c == 2
        Err_surface = error_BE;
    elseif c == 3
        Err_surface = error_ME;
    else
        Err_surface = error_RK;
    end
    % Constructing surface along (Time, dV/dt Rate) to display sharp error ridges
    surf(T_grid,dt_grid,Err_surface,'EdgeColor','none')
    shading interp
    grid on
    box on
    view([-37.5 30])
    title(['3D Error Surface - ',names{c}])
    xlabel('Time (ms)')
    ylabel('\Deltat (ms)')
    zlabel('|Error| (mV)')
    xlim(tspan)
    ylim([min(dt_values) max(dt_values)])
    colorbar
end
sgtitle('3D Error Surfaces and Action Potential Phase Ridges Across Solvers')

%% LOCAL SOLVER & MODEL FUNCTIONS

function [y_FE, y_BE, y_ME, y_RK, t45, y45, exec_times] = HH_solvers(y0, t, dt, tspan)
    N = length(t);
    y_FE = zeros(N, 4);
    y_BE = zeros(N, 4);
    y_ME = zeros(N, 4);
    y_RK = zeros(N, 4);

    y_FE(1,:) = y0;
    y_BE(1,:) = y0;
    y_ME(1,:) = y0;
    y_RK(1,:) = y0;

    % ODE45 Reference
    opts = odeset('RelTol', 1e-6, 'AbsTol', 1e-8);
    [t45, y45] = ode45(@(t_val, y_val) HH_rhs(t_val, y_val), tspan, y0, opts);

    % Forward Euler Timing & Solution
    tic;
    for i = 1:N-1
        k1_fe = HH_rhs(t(i), y_FE(i,:)');
        y_FE(i+1,:) = y_FE(i,:) + dt * k1_fe';
    end
    t_FE = toc;

    % Backward Euler Timing & Solution
    tic;
    for i = 1:N-1
        y_next = y_BE(i,:)';
        for iter = 1:5
            y_next = y_BE(i,:)' + dt * HH_rhs(t(i+1), y_next);
        end
        y_BE(i+1,:) = y_next';
    end
    t_BE = toc;

    % Modified Euler Timing & Solution
    tic;
    for i = 1:N-1
        k1_me = HH_rhs(t(i), y_ME(i,:)');
        y_pred = y_ME(i,:)' + dt * k1_me;
        k2_me = HH_rhs(t(i+1), y_pred);
        y_ME(i+1,:) = y_ME(i,:) + (dt/2) * (k1_me + k2_me)';
    end
    t_ME = toc;

    % RK4 Timing & Solution
    tic;
    for i = 1:N-1
        k1_rk = HH_rhs(t(i), y_RK(i,:)');
        k2_rk = HH_rhs(t(i) + dt/2, y_RK(i,:)' + (dt/2)*k1_rk);
        k3_rk = HH_rhs(t(i) + dt/2, y_RK(i,:)' + (dt/2)*k2_rk);
        k4_rk = HH_rhs(t(i) + dt, y_RK(i,:)' + dt*k3_rk);
        y_RK(i+1,:) = y_RK(i,:) + (dt/6) * (k1_rk + 2*k2_rk + 2*k3_rk + k4_rk)';
    end
    t_RK = toc;

    exec_times = [t_FE, t_BE, t_ME, t_RK];
end

function dydt = HH_rhs(~, y)
    Cm  = 1;
    gNa = 120;
    gK  = 36;
    gL  = 0.3;
    ENa = 55;
    EK  = -77;
    EL  = -54.387;
    I   = 10;

    V = y(1);
    m = y(2);
    h = y(3);
    n = y(4);

    if abs(V+40) < 1e-7
        am = 1;
    else
        am = 0.1*(V+40)/(1-exp(-(V+40)/10));
    end
    bm = 4*exp(-(V+65)/18);

    ah = 0.07*exp(-(V+65)/20);
    bh = 1/(1+exp(-(V+35)/10));

    if abs(V+55) < 1e-7
        an = 0.1;
    else
        an = 0.01*(V+55)/(1-exp(-(V+55)/10));
    end
    bn = 0.125*exp(-(V+65)/80);

    dV = (I - gNa*m^3*h*(V-ENa) - gK*n^4*(V-EK) - gL*(V-EL))/Cm;
    dm = am*(1-m) - bm*m;
    dh = ah*(1-h) - bh*h;
    dn = an*(1-n) - bn*n;

    dydt = [dV; dm; dh; dn];
end