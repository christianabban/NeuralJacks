clc;
clear;
close all;
%% Sodium channel blocker on two patient groups
% Group A has a genetic channelopathy, gNa sits too high
% Group B has glial clearance failure, EK has drifted up
tspan = [0 80];
dt = 0.01;
t = tspan(1):dt:tspan(2);
N = length(t);
V0 = -70;
m0 = 0.05;
h0 = 0.60;
n0 = 0.32;
y0 = [V0 m0 h0 n0];
% Parameters
Cm = 1;
gK = 36;
gL = 0.3;
ENa = 55;
EL = -54.387;
I = 10;
eta = 0.35;
dose = 1;
% group A
gNa_A = 180;
EK_A = -77;
% group B
gNa_B = 120;
EK_B = -65.6;
gNa_A_drug = gNa_A*(1-eta*dose);
gNa_B_drug = gNa_B*(1-eta*dose);
fprintf('group A: %.0f -> %.0f mS/cm2\n',gNa_A,gNa_A_drug);
fprintf('group B: %.0f -> %.0f mS/cm2\n',gNa_B,gNa_B_drug);
% the four runs
gNa_cases = [gNa_A gNa_A_drug gNa_B gNa_B_drug];
EK_cases = [EK_A EK_A EK_B EK_B];
names = {'Group A untreated','Group A + drug','Group B untreated','Group B + drug'};
V_all = zeros(N,4);
%% SOLVING EACH CASE
for c = 1:4
    gNa = gNa_cases(c);
    EK = EK_cases(c);
    y = y0;
    Vout = zeros(N,1);
    Vout(1) = V0;
    % Solving RK4 step
    for i = 1:N-1
        k1 = HHdrug(y,gNa,gK,gL,ENa,EK,EL,Cm,I);
        k2 = HHdrug(y+dt*k1/2,gNa,gK,gL,ENa,EK,EL,Cm,I);
        k3 = HHdrug(y+dt*k2/2,gNa,gK,gL,ENa,EK,EL,Cm,I);
        k4 = HHdrug(y+dt*k3,gNa,gK,gL,ENa,EK,EL,Cm,I);
        y = y + (dt/6)*(k1+2*k2+2*k3+k4);
        Vout(i+1) = y(1);
    end
    V_all(:,c) = Vout;
end
%% spike counts and where each trace settles
fprintf('\n');
for c = 1:4
    V = V_all(:,c);
    pk = find(V(2:end-1) > V(1:end-2) & V(2:end-1) >= V(3:end) & V(2:end-1) > 0) + 1;
    if length(pk) > 1
        rate = 1000/mean(diff(t(pk)));
    else
        rate = 0;
    end
    fprintf('%-20s spikes = %2d, rate = %5.1f Hz, ends at %6.1f mV\n', ...
        names{c},length(pk),rate,V(end));
end
%% FIGURE - 1x2 Subplots (No Drug vs With Drug)
figure('Position',[100 100 1280 500]);

% Subplot 1: No Drug (Group A vs Group B)
subplot(1,2,1)
plot(t, V_all(:,1), 'r', 'LineWidth', 1.5)
hold on
plot(t, V_all(:,3), 'b', 'LineWidth', 1.5)
yline(-55,'k--','Threshold')
yline(-70,'k:','Resting')
hold off
xlim(tspan)
ylim([-95 60])
grid on
title('No Drug (Untreated Baseline)')
xlabel('Time (ms)')
ylabel('Voltage (mV)')
legend('Group A (Channelopathy)','Group B (Clearance Failure)','Location','northeast')

% Subplot 2: With Drug (Group A vs Group B)
subplot(1,2,2)
plot(t, V_all(:,2), 'r--', 'LineWidth', 1.5)
hold on
plot(t, V_all(:,4), 'b--', 'LineWidth', 1.5)
yline(-55,'k--','Threshold')
yline(-70,'k:','Resting')
hold off
xlim(tspan)
ylim([-95 60])
grid on
title('With Na+ Channel Blocker')
xlabel('Time (ms)')
ylabel('Voltage (mV)')
legend('Group A + Drug','Group B + Drug','Location','northeast')

sgtitle('Why the Blocker Works for Group A but not Group B')

%% HH right hand side
function dydt = HHdrug(y,gNa,gK,gL,ENa,EK,EL,Cm,I)
V = y(1);
m = y(2);
h = y(3);
n = y(4);
if abs(V+40) < 1e-7
    am = 1;
else
    am = 0.1*(V+40)/(1-exp(-(V+40)/10));
end
% Computing gate rates
bm = 4*exp(-(V+65)/18);
ah = 0.07*exp(-(V+65)/20);
bh = 1/(1+exp(-(V+35)/10));
if abs(V+55) < 1e-7
    an = 0.1;
else
    an = 0.01*(V+55)/(1-exp(-(V+55)/10));
end
bn = 0.125*exp(-(V+65)/80);
% HH Differential equations
dV = (I - gNa*m^3*h*(V-ENa) - gK*n^4*(V-EK) - gL*(V-EL))/Cm;
dm = am*(1-m) - bm*m;
dh = ah*(1-h) - bh*h;
dn = an*(1-n) - bn*n;
dydt = [dV dm dh dn];
end